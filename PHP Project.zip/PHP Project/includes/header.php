<!DOCTYPE html>
<html lang="en">
<head>
    <style>
        body {
 background-image: url("lopc.jpg");
 background-color: #cccccc;
 background-repeat: no-repeat;
 background-size: cover;
}
    </style>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
    <link rel="stylesheet" href="assets/css/bootstrap5.min.css">
    <link rel="stylesheet" href="assets/css/custom.css">
</head>
<body>
    
