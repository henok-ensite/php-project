<?php
include('config/dbcon.php');
include('authentication.php');
include('includes/header.php');
?>


<div class="container-fluid px-4">
    <h4 class="mt-4">All Report</h4>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Dashboard</li>
        <li class="breadcrumb-item">Report</li>
    </ol>
    <div class="row">
        <div class="col-md-12">
            <?php include('message.php'); ?>
            <div class="card">
                <div class="card-header">
                    <h4>All Report
                    <a href="view_report.php" class="btn btn-danger float-end">Back</a>
                    </h4>
                    <h4>
                    <label for="agency"><h1>Choose Agency:</h1></label>
                    <datalist id="agencies">
                        
                        
                        <?php
                        
                        $query="SELECT fname from company";
                         $query_run = mysqli_query($con, $query);

                         if(mysqli_num_rows($query_run) > 0)
                         {
                            
                             foreach($query_run as $company)
                             {
                                echo "<option name='company_selection'>".$company['fname']."</option>".'<br>';   
                             }
                         }
                        
                        ?>
                    </datalist>        
   <form method='GET' action="view_report.php?cid='<?=$selected?>'">
   <input list="agencies" name="cid" >
    View Report  <input class='btn btn-primary' type="submit" value="Filter by Company" >
   </form>
        </h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                    <table class="table table-bordered table-stripe">
                        <thead>
                        <tr>
                                <th>ID</th>
                                <th>Agency Name</th>
                                <th>Agency Phone-number</th>
                                <th>Agency Address</th>
                                <th>Agency NO. of Employee</th>
                                <th>Employee Full Name</th>
                                <th>Employee Gender</th>
                                <th>Employee Age</th>
                                <th>Employee Phone Number</th>
                                <th>Employeer Full Name</th>
                                <th>Employeer Address</th>
                                <th>Employeer Phone</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $query = "SELECT report.*, employee.fname as efname, 
                            employee.gender as egender,employee.phone as etelephone,
                            employee.age as eage,
                            employeer.fname as erfname, employeer.address as eraddress,
                            employeer.phone as ertelephone,
                            company.cid,company.employeeno,company.fname as cfname, company.address as caddress,
                            company.telephone as ctelephone FROM report,company,employee,employeer
                        where report.cid=company.cid and report.eid=employee.eid and report.erid=employeer.erid";
                            $query_run = mysqli_query($con, $query);

                            if(mysqli_num_rows($query_run) > 0)
                            {
                                $no=1;
                                foreach($query_run as $row)
                                {
                                    ?>
                                    <tr>
                                        <td><?= $no ?></td>
                                        <td><a href="agency-edit.php?id=<?= $row['cid']; ?>"><?= $row['cfname']; ?></a></td>
                                        <td><?= $row['ctelephone']; ?></td>
                                        <td><?= $row['caddress']; ?></td>
                                        <td><?= $row['employeeno']; ?></td>
                                        <td><?= $row['efname']; ?></td>
                                        <td><?= $row['egender']; ?></td>
                                        <td><?= $row['eage']; ?></td>
                                        <td><?= $row['etelephone']; ?></td>
                                        <td><?= $row['erfname']; ?></td>
                                        <td><?= $row['eraddress']; ?></td>
                                        <td><?= $row['ertelephone']; ?></td>
                                        <td><?= $row['created_at']; ?></td>
                                    </tr>
                                    <?php
                                     $no++;
                                }
                            }
                            else
                            {
                            ?>
                                <tr>
                                    <td colspan="13">NO RECORD FOUND</td>
                                </tr>
                            <?php
                            }
                            ?>
                            
                        </tbody>
                    </table>
                </div>
                </div>
            </div>
        </div>

    </div>
</div>
<?php
include('includes/footer.php');
include('includes/script.php');
?>